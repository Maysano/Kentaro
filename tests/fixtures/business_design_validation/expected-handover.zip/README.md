# Customer risk-assessment improvement — provisional design — Reviewed Delivery Handover Package

This is a local, deterministic reviewed handover snapshot of a Kentaro DesignPortfolio.

- `decision-context.yaml` is JSON-compatible YAML and preserves the business, product, and decision context.
- `portfolio/` contains the frozen source design and its rendered canvas.
- `governance/` contains provenance and deterministic readiness findings; it does not contain approvals or platform records.
- `specifications/ai-products/` holds draft AI-product definitions. A review package does not include final ODPS, ODPC, or ODPG files; a structurally complete, human-confirmed final ZIP includes their deterministic, SDK-validated exports.

Regenerate a new package after the source revision or content changes. Validate the package and use package status to detect staleness before consuming it.
